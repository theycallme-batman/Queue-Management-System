
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yash
 */
public class Completeactions {
    NewJFrame2 n2;
    DefaultListModel dm;
    JList<String> JL1;
    JTable JT3;
    Completeactions(){
        n2 = new NewJFrame2();
        dm = n2.getdm();
        JL1 = n2.getjList();
        JT3 = n2.getm();
        
    }
    
    public JTable getm(){
        return JT3;
    }
    
    public DefaultListModel getdm(){
        return dm;
    }
    
    public JList<String> getjList(){
        return JL1;
    }
    
    private void add(String name)
    {
        JL1.setModel(n2.dm);
        n2.dm.addElement(name);
    }
    
    
    public Connection getConnection(){
        Connection con;
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/token","root","Coder@5499");
            return con;
        }
        catch(Exception e)
            {
                    NewJFrame.showMessageDialog(e.getMessage());
                    return null;
            }
    }
    
    public int executeQuery(String query,Connection con)
    {
        int res = 0;
        Statement st;
        try{
            st = con.createStatement();
            res = st.executeUpdate(query);
            }
        catch(Exception e)
            {
                System.out.println(e);
            }
        return res;
    }
    
    
    public void dishselect(int selected,DefaultTableModel model){
        Connection con = getConnection();
        try{
            PreparedStatement ps=con.prepareStatement("Select m.Name,o.Quantity from menu m,orders o where m.Dish_id = o.Dish_id and Order_id = '"+selected+"';");
               ResultSet rs=ps.executeQuery();
               
               model.setRowCount(0);
                    while( rs.next())
                    {
                        Object o[] = {rs.getString("Name"),rs.getString("Quantity")};
                        model.addRow(o);
                    }
        }
        catch(Exception e){
            //JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }
    
    
    
    
    public void deletefromcompleted(Connection con){
        String query3 ="Delete from completed;";
        executeQuery(query3,con);
    }
    
    public void insertintocompleted(int selected,Connection con){
        String query1 ="Insert into completed values('"+selected+"');";
        executeQuery(query1,con);
    }
    
    public void deletefromorders(int selected,Connection con){
        try{
            PreparedStatement ps=con.prepareStatement("Delete from orders where Order_id = '"+selected+"' ;");
            ps.executeUpdate();
        }
        catch(Exception e){
        }
        
    }
    
    public void updatelist(int index,DefaultListModel dm){
        dm.removeElementAt(index);
    }
    
    
    public boolean completeaction(int selected,int index,DefaultListModel dm){
        Connection con= getConnection();
        deletefromcompleted(con);
        insertintocompleted(selected,con);
        deletefromorders(selected,con);
        updatelist(index,dm);
        return true;
    }
    
}


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JLabel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yash
 */
public class refresh extends Thread{
    

    refresh(){
       NewJFrame3.main(null);
        
    }
    
    public void run(){
                try{
               Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/token","root","Coder@5499");
               Statement stmt=(Statement)con.createStatement();
               System.out.println("Hey");
               for(int i = 1;i<2;i--)
                 {
                    String query ="Select id from completed;";
                    ResultSet rs=stmt.executeQuery(query);
                    if( rs.next())
                    {
                        String display = rs.getString("id");
                        NewJFrame3.JLa1.setText(" "+display);
                        System.out.println(""+display);
                        
                    }
                    Thread.sleep(1000);
                 }

            }
        catch(Exception e)
            {
               
            }
    } 
    
    
    
    
    public static void main(String args[]){
        refresh r = new refresh();
        System.out.println("Hello");
        r.start();
    }
}

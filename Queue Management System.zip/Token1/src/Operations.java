/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
/**
 *
 * @author Yash
 */
public class Operations {
    
    public Connection getConnection()
    {
        Connection con;
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/token","root","Coder@5499");
            return con;
        }
        catch(Exception e)
            {
                    NewJFrame.showMessageDialog(e.getMessage());
                    return null;
            }
    }
    
    public int executeQuery(String query,Connection con)
    {
        int res = 0;
        Statement st;
        try{
            st = con.createStatement();
            res = st.executeUpdate(query);
            }
        catch(Exception e)
            {
                System.out.println(e);
            }
        return res;
    }
        
    
    public int insert(int Dish_id,int Order_id,int quantity,int total,DefaultTableModel model){
        int cost = 0;    
        //System.out.println("This class is working");
        try{
            Connection con= getConnection();
            Statement stmt= con.createStatement();
            String query1 = "Select Name,Price from menu where Dish_id = '"+Dish_id+"';";
            ResultSet rs=stmt.executeQuery(query1);
            if( rs.next()){
                String Name = rs.getString("Name");
                int Price = Integer.parseInt(rs.getString("Price"));
                cost = Price*quantity;
                total = total+cost;
                //System.out.println("Inside rs before model");
                model.addRow(new Object[]{Name,quantity,cost});
                //System.out.println("Inside rs after model");
            }
            else NewJFrame.showMessageDialog("Sorry!No such dish's Name");
            
            
            
            String query2 = "Insert into orders values('"+Order_id+"','"+Dish_id+"','"+quantity+"','"+cost+"');";
            executeQuery(query2,con);
        }
        catch(Exception e){
            NewJFrame.showMessageDialog(e.getMessage());
        }
        return total;
    }
    
    
    
    public int delete(int id,DefaultTableModel model){
        int res = 0;
        try{
            Connection con = getConnection();
            String query = "Delete from orders where Dish_id = '"+id+"';";
            res  = executeQuery(query,con);
        }
        catch(Exception e){
            NewJFrame.showMessageDialog(e.getMessage());
        }
        return res;
    }
    
    
    
    
    
    
    public int update(int i,int id,int Order_id,int total,int update_id,int update_qty,DefaultTableModel model){
        int d_price = (int) model.getValueAt(i, 2);
        total = total - d_price;
        try{
                
            Connection con= getConnection();
            Statement stmt=(Statement)con.createStatement();
            String query = "Select Name,Price from menu where Dish_id = '"+update_id+"';";
            ResultSet rs=stmt.executeQuery(query);
            if( rs.next()){
                String Name = rs.getString("Name");
                int Price = Integer.parseInt(rs.getString("Price"));
                int cost = Price*update_qty;
                total = total+cost;
                model.setValueAt(Name, i, 0);
                model.setValueAt(update_qty, i, 1);
                model.setValueAt(cost, i, 2);
                String query1 = "Update orders set Dish_id = '"+update_id+"',Quantity = '"+update_qty+"',Price = '"+cost+"' where Dish_id = '"+id+"' and Order_id = '"+Order_id+"';";
                executeQuery(query1,con);
                       
            }
            else NewJFrame.showMessageDialog("Sorry!No such dish's Name");

        }
        catch(Exception e){
                NewJFrame.showMessageDialog(e.getMessage());
        }    
        return total;
    }
    
    
    
    
    
    public void billgeneration(int total,int Order_id,JTextArea JA1){
        JA1.setText("");
        try{
               //int selected = Integer.parseInt(JL1.getSelectedValue());
               Connection con= getConnection();
              PreparedStatement ps=con.prepareStatement("Select m.Name,o.Quantity,o.Price from menu m,orders o where m.Dish_id = o.Dish_id and Order_id = '"+Order_id+"';");
               ResultSet rs=ps.executeQuery();
                 Calendar timer  = Calendar.getInstance();
        timer.getTime();
        SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
        tTime.format(timer.getTime());
        SimpleDateFormat Tdate = new SimpleDateFormat("dd-MM-yyyy");
        Tdate.format(timer.getTime());

         JA1.append("           Billing System:\n"+
                        "Reference:\t"+ Order_id+
                    "\n========================================\n");
                    while( rs.next())
                    {
                        JA1.append(rs.getString("Name")+"\t"+rs.getString("Quantity")+"\t"+rs.getString("Price")+"\n");
                    }
                    JA1.append( "\n========================================\n"+
                            "Total"+"\t\t"+total+"\n"+
                            
                        "========================================"+
                        "\nDate: "+Tdate.format(timer.getTime()) +
                            "\tTime: "+tTime.format(timer.getTime()) +
                            "\n\tThank You");
                    
            }
        catch(Exception e)
            {
                NewJFrame.showMessageDialog(e.getMessage());
            } 
    }
    
    
    
    
    public int getset(int i,DefaultTableModel model,JTextField TF2,JTextField TF3){
        int id = 0; 
        TF3.setText(model.getValueAt(i, 1).toString());
        try{
               Connection con= getConnection();
               Statement stmt=(Statement)con.createStatement();
               String query = "Select Dish_id from menu where Name = '"+model.getValueAt(i, 0).toString()+"';";
               ResultSet rs=stmt.executeQuery(query);
                    if( rs.next())
                    {
                        id = rs.getInt("Dish_id");
                        TF2.setText(""+id);
                    }
        }
        catch(Exception e){
                    NewJFrame.showMessageDialog(e.getMessage());
        }
        return id;
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Rule;
import org.junit.rules.ErrorCollector;

/**
 *
 * @author Yash
 */
public class OperationsTest {
    
     DefaultTableModel model;
    
    @Rule
    public ErrorCollector error = new ErrorCollector();
    
    
    
    public Connection getConnection()
    {
        Connection con;
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/token","root","Coder@5499");
            return con;
        }
        catch(Exception e)
            {
                    NewJFrame.showMessageDialog(e.getMessage());
                    return null;
            }
    }
    
    public int executeQuery(String query,Connection con)
    {
        int res= 0;
        Statement st;
        try{
            st = con.createStatement();
            res = st.executeUpdate(query);
            }
        catch(Exception e)
            {
                System.out.println(e);
            }
        return res;
    }
    
    
    
    
    
    public OperationsTest() {
        NewJFrame s = new NewJFrame();
        model = s.model;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Test
    public void testfields(){
        NewJFrame s = new NewJFrame();
        int res = Integer.parseInt(s.TF1.getText());
        assertNotNull(res);
        
    }
    
    
    
    
    

    /**
     * Test of getConnection method, of class Operations.
     */
    @Test
    public void testGetConnection() {
        Operations obj = new Operations();
        Connection con = obj.getConnection();
        assertNotNull(con);
    }

    /**
     * Test of insert method, of class Operations.
     */
    @Test
    public void testInsert() {
        
        
        Operations obj = new Operations();
        int Dish_id = 101;
        int Order_id = 100;
        int quantity = 100;
        int total = 0;
        int expectedtotal = 5000;
        int expected_id=0;
        total = obj.insert(Dish_id,Order_id,quantity,total,model);
        try{
           Connection con = getConnection();
           Statement stmt = con.createStatement();
           
           String query = "Select Order_id from orders where Dish_id = '"+Dish_id+"' and Quantity = '"+quantity+"'";
           ResultSet rs = stmt.executeQuery(query);
           if(rs.next()) expected_id = rs.getInt("Order_id");
        }
        catch(Exception e){
           
        }
        System.out.println(""+total+" "+expectedtotal);
        assertEquals(Order_id,expected_id);
        assertEquals(total,expectedtotal);
        obj.delete(Dish_id,model);
    }

    /**
     * Test of delete method, of class Operations.
     */
    @Test
    public void testDelete() {
        Operations obj = new Operations();
        
        
        int Dish_id = 101;
        int Order_id = 100;
        int quantity = 100;
        int total = 0;
        //int expectedtotal = 5000;
        int expected_id = 0;
        total = obj.insert(Dish_id,Order_id,quantity,total,model);
        
        
        
        //int Dish_id = 101;
        int res = obj.delete(Dish_id, model);
        assertNotEquals(res,0);
    }

    /**
     * Test of update method, of class Operations.
     */
    @Test
    public void testUpdate() {
         Operations obj = new Operations();
        int Dish_id = 101;
        int Order_id = 100;
        int quantity = 100;
        int total = 0;
        int update_id = 100;
        int update_qty = 101;
        total = obj.insert(Dish_id,Order_id,quantity,total,model);
        obj.update(0,Dish_id,Order_id,total,update_id,update_qty,model);
        
        
        
        //
        try{
            Connection con = getConnection();
            Statement stmt = con.createStatement();
            String query = "Select Dish_id,Quantity from orders where Order_id ='"+Order_id+"'; ";
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                int Did = rs.getInt("Dish_id");
                int q = rs.getInt("Quantity");
                assertEquals(update_id,Did);
                assertEquals(update_qty,q);
            }
        }
        catch(Exception e){
            System.out.println(e);
            error.addError(e);
        }
        obj.delete(update_id, model);
    }
    
}

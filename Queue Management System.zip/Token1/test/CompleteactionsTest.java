/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

/**
 *
 * @author Yash
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CompleteactionsTest {
    
    Completeactions obj;
    JList<String> list;
    public CompleteactionsTest() {
        obj = new Completeactions();
        list = obj.getjList();
    }
    
    
    
     public Connection getConnection()
    {
        Connection con;
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/token","root","Coder@5499");
            return con;
        }
        catch(Exception e)
            {
                    NewJFrame.showMessageDialog(e.getMessage());
                    return null;
            }
    }
    
    public int executeQuery(String query,Connection con)
    {
        int res= 0;
        Statement st;
        try{
            st = con.createStatement();
            res = st.executeUpdate(query);
            }
        catch(Exception e)
            {
                System.out.println(e);
            }
        return res;
    }
    
    @Test
    public void test1(){
        JList<String> list = obj.getjList();
        Connection con = getConnection();
        String query1 = "Insert into orders values('"+999+"','"+100+"','"+2+"','"+75+"');";
        executeQuery(query1,con);
        String query2 = "Insert into orders values('"+998+"','"+100+"','"+2+"','"+75+"');";
        executeQuery(query2,con);
        String query3 = "Insert into orders values('"+997+"','"+100+"','"+2+"','"+75+"');";
        executeQuery(query3,con);
        String expected[] = {"999","998","997"};
        String original[] = new String[3];
        
        int i = 0;
        try{
            Statement stmt=(Statement)con.createStatement();
            String query4 = "Select distinct Order_id from orders;";
            ResultSet rs=stmt.executeQuery(query4);
            while(rs.next())
            {
                String dish = rs.getString("Order_id");
                original[i] = dish;
                i++;
            }
        }
        catch(Exception e){
            
        }
        
        String query5 = "truncate orders;";
        executeQuery(query5,con);
        for(String s : original) System.out.println(""+s);
        assertArrayEquals(expected,original);
        

    
    }

    
}

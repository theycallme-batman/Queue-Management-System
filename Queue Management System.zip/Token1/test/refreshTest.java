/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Yash
 */
public class refreshTest {

    @Test
    public void testRun() throws InterruptedException {
        refresh obj = new refresh();
               

        Thread.sleep(2000);
        String id = NewJFrame3.JLa1.getText();
        System.out.println(""+id);
        assertTrue(id.isEmpty());
        NewJFrame3.JLa1.setText("999");

        Thread.sleep(2000);
        id = NewJFrame3.JLa1.getText();
        System.out.println(""+id);
        assertFalse(id.isEmpty());
        NewJFrame3.JLa1.setText("");
        
    }

}
